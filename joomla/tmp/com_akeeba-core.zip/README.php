<?php die(); ?>
================================================================================
COPYRIGHT AND DISCLAIMER
================================================================================

Akeeba Backup - Backup, restoration and migration solution for Joomla!
Copyright (C) 2006-2019  Nicholas K. Dionysopoulos / Akeeba Ltd

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

The full text of the license can be found in the LICENSE.txt file inside all of
our ZIP packages.

================================================================================
CONTACT AND SUPPORT
================================================================================

Support is only provided to subscribers and only through our support ticket
system at https://www.akeeba.com/support.html  No other means of support
are provided or accepted. Explicitly, no support will be provided through email,
phone, instant messaging, audio/video call, remote desktop sharing, social media
or any other on-line or off-line method except the support ticket system on our
site.

If you want to file a bug report or contact us for any issue other than support
pelase use the Contact Us page at https://www.akeeba.com/contact-us.html

================================================================================
DOCUMENTATION AND DOWNLOADS
================================================================================

The full documentation is provided free of charge to all. You can find the
documentation on-line in the Documentation section of our website. Should you
need to read it off-line, it is available for download as a PDF file from the
Downloads section of our website.
